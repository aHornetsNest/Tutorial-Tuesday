Copyright

This project and all related files are copyrighted. They are provided for personal, non-commercial use only.
You may not copy, distribute, or use this work for commercial purposes without explicit permission from the author.

Disclaimer

I am not a licensed or professional electrical engineer.
The designs, code, and circuit boards provided here are shared as-is, with no guarantees or warranties of any kind.

By using these files or building the circuits, you acknowledge that:

You do so at your own risk.

You are responsible for verifying the safety, correctness, and suitability of the design for your application.

The author cannot be held liable for any damages, injury, or losses resulting from the use or misuse of this project.

Usage

Intended only for hobbyist and educational purposes.

Do not use in critical systems (aviation, medical devices, life support, etc.).

Always follow safe electrical practices when assembling or testing.