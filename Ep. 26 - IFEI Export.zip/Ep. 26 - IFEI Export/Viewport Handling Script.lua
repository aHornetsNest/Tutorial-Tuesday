
--ViewportHandling
dofile(LockOn_Options.common_script_path.."ViewportHandling.lua")
update_screenspace_diplacement(1, true, 0)
try_find_assigned_viewport("FA_18C_IFEI")


