_  = function(p) return p; end;
name = _('AHNCockpit');
Description = '2560*3064, 2) 1920/1080 top aligned 3) 1024/600 left aligned 4) 1024/600 left aligned'
Viewports =
{
     Center =
     {
          x = 0;
          y = 0;
          width = 2560;
          height = 1440;
          viewDx = 0;
          viewDy = 0;
          aspect = 16 / 9;
     }
}

CENTER_MFCD =
{
     x = 0;
     y = 1864;
     width = 600;
     height = 600;
}

FA_18C_IFEI =
{
     x = -480;
     y = 2484;
     width = 1480;
     height = 590;
}


UIMainView = Viewports.Center
GU_MAIN_VIEWPORT = Viewports.Center